<?php
 
namespace App\Models;
 
use CodeIgniter\Model;
 
class View_summary_monthly_model extends Model{

    protected $table        = 'vw_summary_monthly';
}