<?php
 
namespace App\Models;
 
use CodeIgniter\Model;
 
class View_project_detail_model extends Model{

    protected $table        = 'vw_project_detail';
    protected $primaryKey   = 'id_project';
}