<?php
 
namespace App\Models;
 
use CodeIgniter\Model;
 
class View_activity_pivot_model extends Model{

    protected $table = 'vw_activity_pivot2';
    protected $primaryKey   = 'id_activity';
}