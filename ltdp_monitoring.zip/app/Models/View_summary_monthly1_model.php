<?php
 
namespace App\Models;
 
use CodeIgniter\Model;
 
class View_summary_monthly1_model extends Model{

    protected $table        = 'vw_summary_monthly1';
    protected $primaryKey   = 'id_monthly';
}